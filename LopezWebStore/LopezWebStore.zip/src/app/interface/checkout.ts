export interface checkout {
    country: string;
    creditCard: string;
    firstName: string;
    lastName: string;
    address: string;
    city: string;
    state: string;
    zipCode: string
}