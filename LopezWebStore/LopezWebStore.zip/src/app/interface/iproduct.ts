export interface IProduct {
    id: string;
    pName: string;
    pNameURL: string;
    pDesc: string;
    price: string;
    quantity: number;
    img: string;
}