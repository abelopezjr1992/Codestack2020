export interface User {
    FirstName: string;
    LastName: string;
    email: string;
    createPW: string;
    createUN: string
}