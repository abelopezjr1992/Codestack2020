import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ModalComponent } from 'src/app/shared/modal/modal.component';

@Component({
  selector: 'app-atest',
  templateUrl: './atest.component.html',
  styleUrls: ['./atest.component.scss']
})
export class AtestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
