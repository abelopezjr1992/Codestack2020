export interface Student {
    fN: string;
    lN: string;
    sN: string;
    hob: string;
    nN: string;
    
}
