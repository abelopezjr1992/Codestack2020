export interface Student {
    fName: string;
    lName: string;
    sName: string;
    nName: string;
    hobbies: string;
    
}
